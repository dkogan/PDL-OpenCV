
#
# GENERATED WITH PDL::PP! Don't modify!
#
package PDL::OpenCV;

@EXPORT_OK  = qw( PDL::PP GetElemType PDL::PP GetDimSize PDL::PP Get1D PDL::PP Get2D PDL::PP Get3D PDL::PP GetReal1D PDL::PP GetReal2D PDL::PP GetReal3D PDL::PP Set1D PDL::PP Set2D PDL::PP Set3D PDL::PP SetReal1D PDL::PP SetReal2D PDL::PP SetReal3D PDL::PP Repeat PDL::PP CreateData PDL::PP ReleaseData PDL::PP GetSize PDL::PP Copy PDL::PP Set PDL::PP SetZero PDL::PP Split PDL::PP Merge PDL::PP ConvertScale PDL::PP ConvertScaleAbs PDL::PP Add PDL::PP AddS PDL::PP Sub PDL::PP SubRS PDL::PP Mul PDL::PP Div PDL::PP ScaleAdd PDL::PP AddWeighted PDL::PP DotProduct PDL::PP And PDL::PP AndS PDL::PP Or PDL::PP OrS PDL::PP Xor PDL::PP XorS PDL::PP Not PDL::PP InRange PDL::PP InRangeS PDL::PP Cmp PDL::PP CmpS PDL::PP Min PDL::PP Max PDL::PP MinS PDL::PP MaxS PDL::PP AbsDiff PDL::PP AbsDiffS PDL::PP CartToPolar PDL::PP PolarToCart PDL::PP Pow PDL::PP Exp PDL::PP Log PDL::PP FastArctan PDL::PP Cbrt PDL::PP CheckArr PDL::PP Sort PDL::PP SolveCubic PDL::PP SolvePoly PDL::PP CrossProduct PDL::PP GEMM PDL::PP Transform PDL::PP PerspectiveTransform PDL::PP MulTransposed PDL::PP Transpose PDL::PP CompleteSymm PDL::PP Flip PDL::PP SVD PDL::PP SVBkSb PDL::PP Invert PDL::PP Solve PDL::PP Det PDL::PP Trace PDL::PP EigenVV PDL::PP SetIdentity PDL::PP CalcPCA PDL::PP ProjectPCA PDL::PP BackProjectPCA PDL::PP Mahalanobis PDL::PP Sum PDL::PP CountNonZero PDL::PP Avg PDL::PP Norm PDL::PP Normalize PDL::PP Reduce PDL::PP DFT PDL::PP MulSpectrums PDL::PP GetOptimalDFTSize PDL::PP DCT PDL::PP Line PDL::PP Rectangle PDL::PP Circle PDL::PP Ellipse PDL::PP ColorToScalar PDL::PP LUT PDL::PP UseOptimized PDL::PP SetErrStatus PDL::PP SetErrMode PDL::PP ErrorFromIppStatus PDL::PP CheckHardwareSupport PDL::PP SetNumThreads );
%EXPORT_TAGS = (Func=>[@EXPORT_OK]);

use PDL::Core;
use PDL::Exporter;
use DynaLoader;



   $PDL::OpenCV::VERSION = 0.01;
   @ISA    = ( 'PDL::Exporter','DynaLoader' );
   push @PDL::Core::PP, __PACKAGE__;
   bootstrap PDL::OpenCV $VERSION;





use strict;
use warnings;


=head1 PDL::OpenCV

PDL::OpenCV - PDL interface to OpenCV

=head1 SYNOPSIS

 use PDL::OpenCV;

 my $a = random(3,3);
 my $b = random(3,3);
 my $c = Add($a, $b);

=head1 DESCRIPTION

This is a PDL interface to OpenCV. All the API functions are auto-generated form
the OpenCV headers. The function names and arguments match the OpenCV
C-interface







=head1 FUNCTIONS



=cut






=head2 GetElemType

=for sig

  Signature: (int [o]_return(1);arr(arr0,arr1))

=for ref

 int cvGetElemType(  const CvArr* arr  );



=for bad

GetElemType ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*GetElemType = \&PDL::GetElemType;




=head2 GetDimSize

=for sig

  Signature: (int [o]_return(1);arr(arr0,arr1);int index(1))

=for ref

 int cvGetDimSize(  const CvArr* arr, int index  );



=for bad

GetDimSize ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*GetDimSize = \&PDL::GetDimSize;




=head2 Get1D

=for sig

  Signature: (double [o]_return(4);arr(arr0,arr1);int idx0(1))

=for ref

 CvScalar cvGet1D(  const CvArr* arr, int idx0  );



=for bad

Get1D ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Get1D = \&PDL::Get1D;




=head2 Get2D

=for sig

  Signature: (double [o]_return(4);arr(arr0,arr1);int idx0(1);int idx1(1))

=for ref

 CvScalar cvGet2D(  const CvArr* arr, int idx0, int idx1  );



=for bad

Get2D ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Get2D = \&PDL::Get2D;




=head2 Get3D

=for sig

  Signature: (double [o]_return(4);arr(arr0,arr1);int idx0(1);int idx1(1);int idx2(1))

=for ref

 CvScalar cvGet3D(  const CvArr* arr, int idx0, int idx1, int idx2  );



=for bad

Get3D ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Get3D = \&PDL::Get3D;




=head2 GetReal1D

=for sig

  Signature: (double [o]_return(1);arr(arr0,arr1);int idx0(1))

=for ref

 double cvGetReal1D(  const CvArr* arr, int idx0  );



=for bad

GetReal1D ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*GetReal1D = \&PDL::GetReal1D;




=head2 GetReal2D

=for sig

  Signature: (double [o]_return(1);arr(arr0,arr1);int idx0(1);int idx1(1))

=for ref

 double cvGetReal2D(  const CvArr* arr, int idx0, int idx1  );



=for bad

GetReal2D ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*GetReal2D = \&PDL::GetReal2D;




=head2 GetReal3D

=for sig

  Signature: (double [o]_return(1);arr(arr0,arr1);int idx0(1);int idx1(1);int idx2(1))

=for ref

 double cvGetReal3D(  const CvArr* arr, int idx0, int idx1, int idx2  );



=for bad

GetReal3D ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*GetReal3D = \&PDL::GetReal3D;




=head2 Set1D

=for sig

  Signature: ([io]arr(arr0,arr1);int idx0(1);double value(4))

=for ref

 void cvSet1D(  CvArr* arr, int idx0, CvScalar value  );



=for bad

Set1D ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Set1D = \&PDL::Set1D;




=head2 Set2D

=for sig

  Signature: ([io]arr(arr0,arr1);int idx0(1);int idx1(1);double value(4))

=for ref

 void cvSet2D(  CvArr* arr, int idx0, int idx1, CvScalar value  );



=for bad

Set2D ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Set2D = \&PDL::Set2D;




=head2 Set3D

=for sig

  Signature: ([io]arr(arr0,arr1);int idx0(1);int idx1(1);int idx2(1);double value(4))

=for ref

 void cvSet3D(  CvArr* arr, int idx0, int idx1, int idx2, CvScalar value  );



=for bad

Set3D ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Set3D = \&PDL::Set3D;




=head2 SetReal1D

=for sig

  Signature: ([io]arr(arr0,arr1);int idx0(1);double value(1))

=for ref

 void cvSetReal1D(  CvArr* arr, int idx0, double value  );



=for bad

SetReal1D ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*SetReal1D = \&PDL::SetReal1D;




=head2 SetReal2D

=for sig

  Signature: ([io]arr(arr0,arr1);int idx0(1);int idx1(1);double value(1))

=for ref

 void cvSetReal2D(  CvArr* arr, int idx0, int idx1, double value  );



=for bad

SetReal2D ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*SetReal2D = \&PDL::SetReal2D;




=head2 SetReal3D

=for sig

  Signature: ([io]arr(arr0,arr1);int idx0(1);int idx1(1);int idx2(1);double value(1))

=for ref

 void cvSetReal3D(  CvArr* arr, int idx0,
                        int idx1, int idx2, double value  );



=for bad

SetReal3D ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*SetReal3D = \&PDL::SetReal3D;




=head2 Repeat

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1))

=for ref

 void cvRepeat(  const CvArr* src, CvArr* dst  );



=for bad

Repeat ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Repeat = \&PDL::Repeat;




=head2 CreateData

=for sig

  Signature: ([io]arr(arr0,arr1))

=for ref

 void cvCreateData(  CvArr* arr  );



=for bad

CreateData ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*CreateData = \&PDL::CreateData;




=head2 ReleaseData

=for sig

  Signature: ([io]arr(arr0,arr1))

=for ref

 void cvReleaseData(  CvArr* arr  );



=for bad

ReleaseData ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*ReleaseData = \&PDL::ReleaseData;




=head2 GetSize

=for sig

  Signature: (int [o]_return(2);arr(arr0,arr1))

=for ref

 CvSize cvGetSize(  const CvArr* arr  );



=for bad

GetSize ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*GetSize = \&PDL::GetSize;




=head2 Copy

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1);mask(mask0,mask1))

=for ref

 void cvCopy(  const CvArr* src, CvArr* dst,
                     const CvArr* mask CV_DEFAULT(NULL)  );



=for bad

Copy ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Copy = \&PDL::Copy;




=head2 Set

=for sig

  Signature: ([io]arr(arr0,arr1);double value(4);mask(mask0,mask1))

=for ref

 void cvSet(  CvArr* arr, CvScalar value,
                    const CvArr* mask CV_DEFAULT(NULL)  );



=for bad

Set ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Set = \&PDL::Set;




=head2 SetZero

=for sig

  Signature: ([io]arr(arr0,arr1))

=for ref

 void cvSetZero(  CvArr* arr  );



=for bad

SetZero ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*SetZero = \&PDL::SetZero;




=head2 Split

=for sig

  Signature: (src(src0,src1);[io]dst0(dst00,dst01);[io]dst1(dst10,dst11);[io]dst2(dst20,dst21);[io]dst3(dst30,dst31))

=for ref

 void cvSplit(  const CvArr* src, CvArr* dst0, CvArr* dst1,
                      CvArr* dst2, CvArr* dst3  );



=for bad

Split ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Split = \&PDL::Split;




=head2 Merge

=for sig

  Signature: (src0(src00,src01);src1(src10,src11);src2(src20,src21);src3(src30,src31);[io]dst(dst0,dst1))

=for ref

 void cvMerge(  const CvArr* src0, const CvArr* src1,
                      const CvArr* src2, const CvArr* src3,
                      CvArr* dst  );



=for bad

Merge ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Merge = \&PDL::Merge;




=head2 ConvertScale

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1);double scale(1);double shift(1))

=for ref

 void cvConvertScale(  const CvArr* src, CvArr* dst,
                             double scale CV_DEFAULT(1),
                             double shift CV_DEFAULT(0)  );



=for bad

ConvertScale ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*ConvertScale = \&PDL::ConvertScale;




=head2 ConvertScaleAbs

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1);double scale(1);double shift(1))

=for ref

 void cvConvertScaleAbs(  const CvArr* src, CvArr* dst,
                                double scale CV_DEFAULT(1),
                                double shift CV_DEFAULT(0)  );



=for bad

ConvertScaleAbs ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*ConvertScaleAbs = \&PDL::ConvertScaleAbs;




=head2 Add

=for sig

  Signature: (src1(src10,src11);src2(src20,src21);[io]dst(dst0,dst1);mask(mask0,mask1))

=for ref

 void cvAdd(  const CvArr* src1, const CvArr* src2, CvArr* dst,
                    const CvArr* mask CV_DEFAULT(NULL) );



=for bad

Add ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Add = \&PDL::Add;




=head2 AddS

=for sig

  Signature: (src(src0,src1);double value(4);[io]dst(dst0,dst1);mask(mask0,mask1))

=for ref

 void cvAddS(  const CvArr* src, CvScalar value, CvArr* dst,
                     const CvArr* mask CV_DEFAULT(NULL) );



=for bad

AddS ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*AddS = \&PDL::AddS;




=head2 Sub

=for sig

  Signature: (src1(src10,src11);src2(src20,src21);[io]dst(dst0,dst1);mask(mask0,mask1))

=for ref

 void cvSub(  const CvArr* src1, const CvArr* src2, CvArr* dst,
                    const CvArr* mask CV_DEFAULT(NULL) );



=for bad

Sub ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Sub = \&PDL::Sub;




=head2 SubRS

=for sig

  Signature: (src(src0,src1);double value(4);[io]dst(dst0,dst1);mask(mask0,mask1))

=for ref

 void cvSubRS(  const CvArr* src, CvScalar value, CvArr* dst,
                      const CvArr* mask CV_DEFAULT(NULL) );



=for bad

SubRS ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*SubRS = \&PDL::SubRS;




=head2 Mul

=for sig

  Signature: (src1(src10,src11);src2(src20,src21);[io]dst(dst0,dst1);double scale(1))

=for ref

 void cvMul(  const CvArr* src1, const CvArr* src2,
                    CvArr* dst, double scale CV_DEFAULT(1)  );



=for bad

Mul ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Mul = \&PDL::Mul;




=head2 Div

=for sig

  Signature: (src1(src10,src11);src2(src20,src21);[io]dst(dst0,dst1);double scale(1))

=for ref

 void cvDiv(  const CvArr* src1, const CvArr* src2,
                    CvArr* dst, double scale CV_DEFAULT(1) );



=for bad

Div ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Div = \&PDL::Div;




=head2 ScaleAdd

=for sig

  Signature: (src1(src10,src11);double scale(4);src2(src20,src21);[io]dst(dst0,dst1))

=for ref

 void cvScaleAdd(  const CvArr* src1, CvScalar scale,
                         const CvArr* src2, CvArr* dst  );



=for bad

ScaleAdd ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*ScaleAdd = \&PDL::ScaleAdd;




=head2 AddWeighted

=for sig

  Signature: (src1(src10,src11);double alpha(1);src2(src20,src21);double beta(1);double gamma(1);[io]dst(dst0,dst1))

=for ref

 void cvAddWeighted(  const CvArr* src1, double alpha,
                            const CvArr* src2, double beta,
                            double gamma, CvArr* dst  );



=for bad

AddWeighted ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*AddWeighted = \&PDL::AddWeighted;




=head2 DotProduct

=for sig

  Signature: (double [o]_return(1);src1(src10,src11);src2(src20,src21))

=for ref

 double cvDotProduct(  const CvArr* src1, const CvArr* src2  );



=for bad

DotProduct ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*DotProduct = \&PDL::DotProduct;




=head2 And

=for sig

  Signature: (src1(src10,src11);src2(src20,src21);[io]dst(dst0,dst1);mask(mask0,mask1))

=for ref

 void cvAnd(  const CvArr* src1, const CvArr* src2,
                  CvArr* dst, const CvArr* mask CV_DEFAULT(NULL) );



=for bad

And ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*And = \&PDL::And;




=head2 AndS

=for sig

  Signature: (src(src0,src1);double value(4);[io]dst(dst0,dst1);mask(mask0,mask1))

=for ref

 void cvAndS(  const CvArr* src, CvScalar value,
                   CvArr* dst, const CvArr* mask CV_DEFAULT(NULL) );



=for bad

AndS ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*AndS = \&PDL::AndS;




=head2 Or

=for sig

  Signature: (src1(src10,src11);src2(src20,src21);[io]dst(dst0,dst1);mask(mask0,mask1))

=for ref

 void cvOr(  const CvArr* src1, const CvArr* src2,
                 CvArr* dst, const CvArr* mask CV_DEFAULT(NULL) );



=for bad

Or ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Or = \&PDL::Or;




=head2 OrS

=for sig

  Signature: (src(src0,src1);double value(4);[io]dst(dst0,dst1);mask(mask0,mask1))

=for ref

 void cvOrS(  const CvArr* src, CvScalar value,
                  CvArr* dst, const CvArr* mask CV_DEFAULT(NULL) );



=for bad

OrS ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*OrS = \&PDL::OrS;




=head2 Xor

=for sig

  Signature: (src1(src10,src11);src2(src20,src21);[io]dst(dst0,dst1);mask(mask0,mask1))

=for ref

 void cvXor(  const CvArr* src1, const CvArr* src2,
                  CvArr* dst, const CvArr* mask CV_DEFAULT(NULL) );



=for bad

Xor ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Xor = \&PDL::Xor;




=head2 XorS

=for sig

  Signature: (src(src0,src1);double value(4);[io]dst(dst0,dst1);mask(mask0,mask1))

=for ref

 void cvXorS(  const CvArr* src, CvScalar value,
                   CvArr* dst, const CvArr* mask CV_DEFAULT(NULL) );



=for bad

XorS ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*XorS = \&PDL::XorS;




=head2 Not

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1))

=for ref

 void cvNot(  const CvArr* src, CvArr* dst  );



=for bad

Not ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Not = \&PDL::Not;




=head2 InRange

=for sig

  Signature: (src(src0,src1);lower(lower0,lower1);upper(upper0,upper1);[io]dst(dst0,dst1))

=for ref

 void cvInRange(  const CvArr* src, const CvArr* lower,
                      const CvArr* upper, CvArr* dst  );



=for bad

InRange ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*InRange = \&PDL::InRange;




=head2 InRangeS

=for sig

  Signature: (src(src0,src1);double lower(4);double upper(4);[io]dst(dst0,dst1))

=for ref

 void cvInRangeS(  const CvArr* src, CvScalar lower,
                       CvScalar upper, CvArr* dst  );



=for bad

InRangeS ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*InRangeS = \&PDL::InRangeS;




=head2 Cmp

=for sig

  Signature: (src1(src10,src11);src2(src20,src21);[io]dst(dst0,dst1);int cmp_op(1))

=for ref

 void cvCmp(  const CvArr* src1, const CvArr* src2, CvArr* dst, int cmp_op  );



=for bad

Cmp ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Cmp = \&PDL::Cmp;




=head2 CmpS

=for sig

  Signature: (src(src0,src1);double value(1);[io]dst(dst0,dst1);int cmp_op(1))

=for ref

 void cvCmpS(  const CvArr* src, double value, CvArr* dst, int cmp_op  );



=for bad

CmpS ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*CmpS = \&PDL::CmpS;




=head2 Min

=for sig

  Signature: (src1(src10,src11);src2(src20,src21);[io]dst(dst0,dst1))

=for ref

 void cvMin(  const CvArr* src1, const CvArr* src2, CvArr* dst  );



=for bad

Min ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Min = \&PDL::Min;




=head2 Max

=for sig

  Signature: (src1(src10,src11);src2(src20,src21);[io]dst(dst0,dst1))

=for ref

 void cvMax(  const CvArr* src1, const CvArr* src2, CvArr* dst  );



=for bad

Max ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Max = \&PDL::Max;




=head2 MinS

=for sig

  Signature: (src(src0,src1);double value(1);[io]dst(dst0,dst1))

=for ref

 void cvMinS(  const CvArr* src, double value, CvArr* dst  );



=for bad

MinS ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*MinS = \&PDL::MinS;




=head2 MaxS

=for sig

  Signature: (src(src0,src1);double value(1);[io]dst(dst0,dst1))

=for ref

 void cvMaxS(  const CvArr* src, double value, CvArr* dst  );



=for bad

MaxS ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*MaxS = \&PDL::MaxS;




=head2 AbsDiff

=for sig

  Signature: (src1(src10,src11);src2(src20,src21);[io]dst(dst0,dst1))

=for ref

 void cvAbsDiff(  const CvArr* src1, const CvArr* src2, CvArr* dst  );



=for bad

AbsDiff ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*AbsDiff = \&PDL::AbsDiff;




=head2 AbsDiffS

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1);double value(4))

=for ref

 void cvAbsDiffS(  const CvArr* src, CvArr* dst, CvScalar value  );



=for bad

AbsDiffS ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*AbsDiffS = \&PDL::AbsDiffS;




=head2 CartToPolar

=for sig

  Signature: (x(x0,x1);y(y0,y1);[io]magnitude(magnitude0,magnitude1);[io]angle(angle0,angle1);int angle_in_degrees(1))

=for ref

 void cvCartToPolar(  const CvArr* x, const CvArr* y,
                            CvArr* magnitude, CvArr* angle CV_DEFAULT(NULL),
                            int angle_in_degrees CV_DEFAULT(0) );



=for bad

CartToPolar ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*CartToPolar = \&PDL::CartToPolar;




=head2 PolarToCart

=for sig

  Signature: (magnitude(magnitude0,magnitude1);angle(angle0,angle1);[io]x(x0,x1);[io]y(y0,y1);int angle_in_degrees(1))

=for ref

 void cvPolarToCart(  const CvArr* magnitude, const CvArr* angle,
                            CvArr* x, CvArr* y,
                            int angle_in_degrees CV_DEFAULT(0) );



=for bad

PolarToCart ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*PolarToCart = \&PDL::PolarToCart;




=head2 Pow

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1);double power(1))

=for ref

 void cvPow(  const CvArr* src, CvArr* dst, double power  );



=for bad

Pow ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Pow = \&PDL::Pow;




=head2 Exp

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1))

=for ref

 void cvExp(  const CvArr* src, CvArr* dst  );



=for bad

Exp ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Exp = \&PDL::Exp;




=head2 Log

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1))

=for ref

 void cvLog(  const CvArr* src, CvArr* dst  );



=for bad

Log ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Log = \&PDL::Log;




=head2 FastArctan

=for sig

  Signature: (float [o]_return(1);float y(1);float x(1))

=for ref

 float cvFastArctan(  float y, float x  );



=for bad

FastArctan ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*FastArctan = \&PDL::FastArctan;




=head2 Cbrt

=for sig

  Signature: (float [o]_return(1);float value(1))

=for ref

 float cvCbrt(  float value  );



=for bad

Cbrt ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Cbrt = \&PDL::Cbrt;




=head2 CheckArr

=for sig

  Signature: (int [o]_return(1);arr(arr0,arr1);int flags(1);double min_val(1);double max_val(1))

=for ref

 int cvCheckArr(  const CvArr* arr, int flags CV_DEFAULT(0),
                        double min_val CV_DEFAULT(0), double max_val CV_DEFAULT(0) );



=for bad

CheckArr ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*CheckArr = \&PDL::CheckArr;




=head2 Sort

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1);[io]idxmat(idxmat0,idxmat1);int flags(1))

=for ref

 void cvSort(  const CvArr* src, CvArr* dst CV_DEFAULT(NULL),
                    CvArr* idxmat CV_DEFAULT(NULL),
                    int flags CV_DEFAULT(0) );



=for bad

Sort ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Sort = \&PDL::Sort;




=head2 SolveCubic

=for sig

  Signature: (int [o]_return(1);coeffs(coeffs0,coeffs1);[io]roots(roots0,roots1))

=for ref

 int cvSolveCubic(  const CvMat* coeffs, CvMat* roots  );



=for bad

SolveCubic ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*SolveCubic = \&PDL::SolveCubic;




=head2 SolvePoly

=for sig

  Signature: (coeffs(coeffs0,coeffs1);[io]roots2(roots20,roots21);int maxiter(1);int fig(1))

=for ref

 void cvSolvePoly( const CvMat* coeffs, CvMat *roots2,
   int maxiter CV_DEFAULT(20), int fig CV_DEFAULT(100) );



=for bad

SolvePoly ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*SolvePoly = \&PDL::SolvePoly;




=head2 CrossProduct

=for sig

  Signature: (src1(src10,src11);src2(src20,src21);[io]dst(dst0,dst1))

=for ref

 void cvCrossProduct(  const CvArr* src1, const CvArr* src2, CvArr* dst  );



=for bad

CrossProduct ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*CrossProduct = \&PDL::CrossProduct;




=head2 GEMM

=for sig

  Signature: (src1(src10,src11);src2(src20,src21);double alpha(1);src3(src30,src31);double beta(1);[io]dst(dst0,dst1);int tABC(1))

=for ref

 void cvGEMM(  const CvArr* src1, const CvArr* src2, double alpha,
                     const CvArr* src3, double beta, CvArr* dst,
                     int tABC CV_DEFAULT(0) );



=for bad

GEMM ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*GEMM = \&PDL::GEMM;




=head2 Transform

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1);transmat(transmat0,transmat1);shiftvec(shiftvec0,shiftvec1))

=for ref

 void cvTransform(  const CvArr* src, CvArr* dst,
                          const CvMat* transmat,
                          const CvMat* shiftvec CV_DEFAULT(NULL) );



=for bad

Transform ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Transform = \&PDL::Transform;




=head2 PerspectiveTransform

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1);mat(mat0,mat1))

=for ref

 void cvPerspectiveTransform(  const CvArr* src, CvArr* dst,
                                     const CvMat* mat  );



=for bad

PerspectiveTransform ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*PerspectiveTransform = \&PDL::PerspectiveTransform;




=head2 MulTransposed

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1);int order(1);delta(delta0,delta1);double scale(1))

=for ref

 void cvMulTransposed(  const CvArr* src, CvArr* dst, int order,
                             const CvArr* delta CV_DEFAULT(NULL),
                             double scale CV_DEFAULT(1.)  );



=for bad

MulTransposed ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*MulTransposed = \&PDL::MulTransposed;




=head2 Transpose

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1))

=for ref

 void cvTranspose(  const CvArr* src, CvArr* dst  );



=for bad

Transpose ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Transpose = \&PDL::Transpose;




=head2 CompleteSymm

=for sig

  Signature: ([io]matrix(matrix0,matrix1);int LtoR(1))

=for ref

 void cvCompleteSymm(  CvMat* matrix, int LtoR CV_DEFAULT(0)  );



=for bad

CompleteSymm ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*CompleteSymm = \&PDL::CompleteSymm;




=head2 Flip

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1);int flip_mode(1))

=for ref

 void cvFlip(  const CvArr* src, CvArr* dst CV_DEFAULT(NULL),
                     int flip_mode CV_DEFAULT(0) );



=for bad

Flip ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Flip = \&PDL::Flip;




=head2 SVD

=for sig

  Signature: ([io]A(A0,A1);[io]W(W0,W1);[io]U(U0,U1);[io]V(V0,V1);int flags(1))

=for ref

 void cvSVD(  CvArr* A, CvArr* W, CvArr* U CV_DEFAULT(NULL),
                     CvArr* V CV_DEFAULT(NULL), int flags CV_DEFAULT(0) );



=for bad

SVD ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*SVD = \&PDL::SVD;




=head2 SVBkSb

=for sig

  Signature: (W(W0,W1);U(U0,U1);V(V0,V1);B(B0,B1);[io]X(X0,X1);int flags(1))

=for ref

 void cvSVBkSb(  const CvArr* W, const CvArr* U,
                        const CvArr* V, const CvArr* B,
                        CvArr* X, int flags  );



=for bad

SVBkSb ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*SVBkSb = \&PDL::SVBkSb;




=head2 Invert

=for sig

  Signature: (double [o]_return(1);src(src0,src1);[io]dst(dst0,dst1);int method(1))

=for ref

 double cvInvert(  const CvArr* src, CvArr* dst,
                         int method CV_DEFAULT(CV_LU) );



=for bad

Invert ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Invert = \&PDL::Invert;




=head2 Solve

=for sig

  Signature: (int [o]_return(1);src1(src10,src11);src2(src20,src21);[io]dst(dst0,dst1);int method(1))

=for ref

 int cvSolve(  const CvArr* src1, const CvArr* src2, CvArr* dst,
                     int method CV_DEFAULT(CV_LU) );



=for bad

Solve ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Solve = \&PDL::Solve;




=head2 Det

=for sig

  Signature: (double [o]_return(1);mat(mat0,mat1))

=for ref

 double cvDet(  const CvArr* mat  );



=for bad

Det ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Det = \&PDL::Det;




=head2 Trace

=for sig

  Signature: (double [o]_return(4);mat(mat0,mat1))

=for ref

 CvScalar cvTrace(  const CvArr* mat  );



=for bad

Trace ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Trace = \&PDL::Trace;




=head2 EigenVV

=for sig

  Signature: ([io]mat(mat0,mat1);[io]evects(evects0,evects1);[io]evals(evals0,evals1);double eps(1);int lowindex(1);int highindex(1))

=for ref

 void cvEigenVV(  CvArr* mat, CvArr* evects, CvArr* evals,
                        double eps CV_DEFAULT(0),
                        int lowindex CV_DEFAULT(-1),
                        int highindex CV_DEFAULT(-1) );



=for bad

EigenVV ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*EigenVV = \&PDL::EigenVV;




=head2 SetIdentity

=for sig

  Signature: ([io]mat(mat0,mat1);double value(4))

=for ref

 void cvSetIdentity(  CvArr* mat, CvScalar value CV_DEFAULT(cvRealScalar(1))  );



=for bad

SetIdentity ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*SetIdentity = \&PDL::SetIdentity;




=head2 CalcPCA

=for sig

  Signature: (data(data0,data1);[io]mean(mean0,mean1);[io]eigenvals(eigenvals0,eigenvals1);[io]eigenvects(eigenvects0,eigenvects1);int flags(1))

=for ref

 void cvCalcPCA(  const CvArr* data, CvArr* mean,
                        CvArr* eigenvals, CvArr* eigenvects, int flags  );



=for bad

CalcPCA ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*CalcPCA = \&PDL::CalcPCA;




=head2 ProjectPCA

=for sig

  Signature: (data(data0,data1);mean(mean0,mean1);eigenvects(eigenvects0,eigenvects1);[io]result(result0,result1))

=for ref

 void cvProjectPCA(  const CvArr* data, const CvArr* mean,
                           const CvArr* eigenvects, CvArr* result  );



=for bad

ProjectPCA ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*ProjectPCA = \&PDL::ProjectPCA;




=head2 BackProjectPCA

=for sig

  Signature: (proj(proj0,proj1);mean(mean0,mean1);eigenvects(eigenvects0,eigenvects1);[io]result(result0,result1))

=for ref

 void cvBackProjectPCA(  const CvArr* proj, const CvArr* mean,
                               const CvArr* eigenvects, CvArr* result  );



=for bad

BackProjectPCA ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*BackProjectPCA = \&PDL::BackProjectPCA;




=head2 Mahalanobis

=for sig

  Signature: (double [o]_return(1);vec1(vec10,vec11);vec2(vec20,vec21);mat(mat0,mat1))

=for ref

 double cvMahalanobis(  const CvArr* vec1, const CvArr* vec2, const CvArr* mat  );



=for bad

Mahalanobis ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Mahalanobis = \&PDL::Mahalanobis;




=head2 Sum

=for sig

  Signature: (double [o]_return(4);arr(arr0,arr1))

=for ref

 CvScalar cvSum(  const CvArr* arr  );



=for bad

Sum ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Sum = \&PDL::Sum;




=head2 CountNonZero

=for sig

  Signature: (int [o]_return(1);arr(arr0,arr1))

=for ref

 int cvCountNonZero(  const CvArr* arr  );



=for bad

CountNonZero ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*CountNonZero = \&PDL::CountNonZero;




=head2 Avg

=for sig

  Signature: (double [o]_return(4);arr(arr0,arr1);mask(mask0,mask1))

=for ref

 CvScalar cvAvg(  const CvArr* arr, const CvArr* mask CV_DEFAULT(NULL)  );



=for bad

Avg ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Avg = \&PDL::Avg;




=head2 Norm

=for sig

  Signature: (double [o]_return(1);arr1(arr10,arr11);arr2(arr20,arr21);int norm_type(1);mask(mask0,mask1))

=for ref

 double cvNorm(  const CvArr* arr1, const CvArr* arr2 CV_DEFAULT(NULL),
                       int norm_type CV_DEFAULT(CV_L2),
                       const CvArr* mask CV_DEFAULT(NULL)  );



=for bad

Norm ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Norm = \&PDL::Norm;




=head2 Normalize

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1);double a(1);double b(1);int norm_type(1);mask(mask0,mask1))

=for ref

 void cvNormalize(  const CvArr* src, CvArr* dst,
                          double a CV_DEFAULT(1.), double b CV_DEFAULT(0.),
                          int norm_type CV_DEFAULT(CV_L2),
                          const CvArr* mask CV_DEFAULT(NULL)  );



=for bad

Normalize ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Normalize = \&PDL::Normalize;




=head2 Reduce

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1);int dim(1);int op(1))

=for ref

 void cvReduce(  const CvArr* src, CvArr* dst, int dim CV_DEFAULT(-1),
                       int op CV_DEFAULT(CV_REDUCE_SUM)  );



=for bad

Reduce ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Reduce = \&PDL::Reduce;




=head2 DFT

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1);int flags(1);int nonzero_rows(1))

=for ref

 void cvDFT(  const CvArr* src, CvArr* dst, int flags,
                    int nonzero_rows CV_DEFAULT(0)  );



=for bad

DFT ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*DFT = \&PDL::DFT;




=head2 MulSpectrums

=for sig

  Signature: (src1(src10,src11);src2(src20,src21);[io]dst(dst0,dst1);int flags(1))

=for ref

 void cvMulSpectrums(  const CvArr* src1, const CvArr* src2,
                             CvArr* dst, int flags  );



=for bad

MulSpectrums ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*MulSpectrums = \&PDL::MulSpectrums;




=head2 GetOptimalDFTSize

=for sig

  Signature: (int [o]_return(1);int size0(1))

=for ref

 int cvGetOptimalDFTSize(  int size0  );



=for bad

GetOptimalDFTSize ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*GetOptimalDFTSize = \&PDL::GetOptimalDFTSize;




=head2 DCT

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1);int flags(1))

=for ref

 void cvDCT(  const CvArr* src, CvArr* dst, int flags  );



=for bad

DCT ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*DCT = \&PDL::DCT;




=head2 Line

=for sig

  Signature: ([io]img(img0,img1);int pt1(2);int pt2(2);double color(4);int thickness(1);int line_type(1);int shift(1))

=for ref

 void cvLine(  CvArr* img, CvPoint pt1, CvPoint pt2,
                     CvScalar color, int thickness CV_DEFAULT(1),
                     int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0)  );



=for bad

Line ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Line = \&PDL::Line;




=head2 Rectangle

=for sig

  Signature: ([io]img(img0,img1);int pt1(2);int pt2(2);double color(4);int thickness(1);int line_type(1);int shift(1))

=for ref

 void cvRectangle(  CvArr* img, CvPoint pt1, CvPoint pt2,
                          CvScalar color, int thickness CV_DEFAULT(1),
                          int line_type CV_DEFAULT(8),
                          int shift CV_DEFAULT(0) );



=for bad

Rectangle ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Rectangle = \&PDL::Rectangle;




=head2 Circle

=for sig

  Signature: ([io]img(img0,img1);int center(2);int radius(1);double color(4);int thickness(1);int line_type(1);int shift(1))

=for ref

 void cvCircle(  CvArr* img, CvPoint center, int radius,
                       CvScalar color, int thickness CV_DEFAULT(1),
                       int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0) );



=for bad

Circle ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Circle = \&PDL::Circle;




=head2 Ellipse

=for sig

  Signature: ([io]img(img0,img1);int center(2);int axes(2);double angle(1);double start_angle(1);double end_angle(1);double color(4);int thickness(1);int line_type(1);int shift(1))

=for ref

 void cvEllipse(  CvArr* img, CvPoint center, CvSize axes,
                        double angle, double start_angle, double end_angle,
                        CvScalar color, int thickness CV_DEFAULT(1),
                        int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0) );



=for bad

Ellipse ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*Ellipse = \&PDL::Ellipse;




=head2 ColorToScalar

=for sig

  Signature: (double [o]_return(4);double packed_color(1);int arrtype(1))

=for ref

 CvScalar cvColorToScalar(  double packed_color, int arrtype  );



=for bad

ColorToScalar ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*ColorToScalar = \&PDL::ColorToScalar;




=head2 LUT

=for sig

  Signature: (src(src0,src1);[io]dst(dst0,dst1);lut(lut0,lut1))

=for ref

 void cvLUT(  const CvArr* src, CvArr* dst, const CvArr* lut  );



=for bad

LUT ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*LUT = \&PDL::LUT;




=head2 UseOptimized

=for sig

  Signature: (int [o]_return(1);int on_off(1))

=for ref

 int cvUseOptimized(  int on_off  );



=for bad

UseOptimized ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*UseOptimized = \&PDL::UseOptimized;




=head2 SetErrStatus

=for sig

  Signature: (int status(1))

=for ref

 void cvSetErrStatus(  int status  );



=for bad

SetErrStatus ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*SetErrStatus = \&PDL::SetErrStatus;




=head2 SetErrMode

=for sig

  Signature: (int [o]_return(1);int mode(1))

=for ref

 int cvSetErrMode(  int mode  );



=for bad

SetErrMode ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*SetErrMode = \&PDL::SetErrMode;




=head2 ErrorFromIppStatus

=for sig

  Signature: (int [o]_return(1);int ipp_status(1))

=for ref

 int cvErrorFromIppStatus(  int ipp_status  );



=for bad

ErrorFromIppStatus ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*ErrorFromIppStatus = \&PDL::ErrorFromIppStatus;




=head2 CheckHardwareSupport

=for sig

  Signature: (int [o]_return(1);int feature(1))

=for ref

 int cvCheckHardwareSupport( int feature );



=for bad

CheckHardwareSupport ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*CheckHardwareSupport = \&PDL::CheckHardwareSupport;




=head2 SetNumThreads

=for sig

  Signature: (int threads(1))

=for ref

 void cvSetNumThreads(  int threads CV_DEFAULT(0)  );



=for bad

SetNumThreads ignores the bad-value flag of the input piddles.
It will set the bad-value flag of all output piddles if the flag is set for any of the input piddles.


=cut






*SetNumThreads = \&PDL::SetNumThreads;


;



# Exit with OK status

1;

		   